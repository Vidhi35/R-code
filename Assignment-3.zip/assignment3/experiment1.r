logical_vector <- rep(c(TRUE, FALSE), length.out = 12)
print(logical_vector)


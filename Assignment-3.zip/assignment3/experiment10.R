words <- c("Hello", "R", "World")
paste_result <- paste(words, collapse = " ")
cat_result <- cat(words, sep = " ")
print(paste_result)
cat(cat_result, "\n")


text <- "apple, apple, and apple"
sub_text <- sub("apple", "orange", text) 
gsub_text <- gsub("apple", "orange", text) 
print(sub_text)
print(gsub_text)


gender <- c("male", "female", "male", "female")
gender_factor <- factor(gender)
print(gender_factor)
print(levels(gender_factor))


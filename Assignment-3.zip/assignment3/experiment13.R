months <- c("Jan", "Mar", "Feb", "Apr", "May", "Dec", "Nov")
ordered_months <- factor(months, levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"), ordered = TRUE)
print(ordered_months)


gender <- factor(c("male", "female", "female", "male", "female"))
only_female <- gender[gender == "female"]
print(only_female)


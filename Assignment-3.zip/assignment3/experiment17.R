vec1 <- c(TRUE, FALSE, TRUE, FALSE)
vec2 <- c(FALSE, FALSE, TRUE, TRUE)

and_result <- vec1 & vec2
or_result <- vec1 | vec2
not_result <- !vec1

print(and_result)
print(or_result)
print(not_result)


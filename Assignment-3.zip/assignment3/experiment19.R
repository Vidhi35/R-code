str1 <- "Apple"
str2 <- "Banana"
comparison_result <- str1 < str2 
print(comparison_result)



num_vector <- c(10, -5, 7, -3, 0, -8, 15)
negative_values <- num_vector < 0
print(negative_values)


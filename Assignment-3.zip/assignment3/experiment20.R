text <- "This is a newline:\nThis is a tab:\tThis is a backslash:\\"
cat(text, "\n")


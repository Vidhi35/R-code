
matrix1 <- matrix(1:12, nrow = 3, byrow = TRUE)
matrix2 <- matrix(12:1, nrow = 3, byrow = TRUE)

comparison <- matrix1 == matrix2

print(matrix1)
print(matrix2)
print(comparison)


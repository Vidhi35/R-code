vec1 <- c(1, 2, 3, 4)
vec2 <- 1:10
result <- vec1 + vec2
print(result)


logical_vec <- c(TRUE, FALSE, TRUE, TRUE, FALSE, TRUE)
sum_true <- sum(logical_vec)
print(sum_true)


num_vec <- c(5, 15, 20, 8, 12, 3)
greater_than_10 <- num_vec[num_vec > 10]
print(greater_than_10)


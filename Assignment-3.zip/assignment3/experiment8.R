text <- "Hello World! Welcome to R programming"
char_count <- nchar(text)
substring_text <- substr(text, 26, nchar(text))
print(char_count)
print(substring_text)


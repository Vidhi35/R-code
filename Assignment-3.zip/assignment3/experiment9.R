result <- paste("Data", "Science", "R", sep = "-")
print(result)

